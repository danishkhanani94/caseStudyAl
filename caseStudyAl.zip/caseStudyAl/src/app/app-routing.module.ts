import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainPageComponent } from './components/main-page/main-page.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { ProductListingComponent } from './components/product-listing/product-listing.component';

const routes: Routes = [
  {path: '' , redirectTo: 'home/product-category/beverages', pathMatch: 'full'},
  {
    path: 'home/product-category/:categoryName', component: MainPageComponent, children: [
      { path: '', component: ProductListingComponent }
    ]
  },
  {
    path: 'home/product-detail/:productName', component: MainPageComponent, children: [
      { path: '', component: ProductDetailsComponent }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

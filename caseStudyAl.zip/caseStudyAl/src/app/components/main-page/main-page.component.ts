import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  category = '';
  constructor(private route: Router, private activatedRoute: ActivatedRoute, private apiService: ApiServiceService) { }

  ngOnInit(): void {
    this.category = this.activatedRoute.snapshot.params.categoryName;
  }

  navigateToCategories(categoryName) {
    console.log('navigate', categoryName)
    this.route.navigate([`/home/product-category/${categoryName}`]);
    this.apiService.switchCategory.next(categoryName);
  }
}

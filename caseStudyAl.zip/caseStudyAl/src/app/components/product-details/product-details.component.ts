import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private apiService: ApiServiceService, private activatedRoute: ActivatedRoute) { }
  productName = '';
  newData;
  defaultObj;
  dataLoading = true;
  ngOnInit() {
    this.productName = this.activatedRoute.snapshot.params.productName;
    console.log(this.productName)
    this.getProductDetails(this.productName);
  }

  getProductDetails(productName) {
    this.apiService.getProductDetail(productName).subscribe(res => {
      console.log(res);
      const response = res[0];
      this.defaultObj = response.default;
      const newObj = {
        title: this.defaultObj.name,
        price: this.defaultObj.price,
        rewardPoints: this.defaultObj.rewards_point,
        description: this.defaultObj.description,
        variations: response.variations,
        image: this.defaultObj.image
      }
      this.newData = newObj;
      console.log(this.newData)
      this.dataLoading = false;
    })
  }
}

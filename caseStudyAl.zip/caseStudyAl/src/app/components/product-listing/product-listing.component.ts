import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-product-listing',
  templateUrl: './product-listing.component.html',
  styleUrls: ['./product-listing.component.css']
})
export class ProductListingComponent implements OnInit {

  constructor(private apiService: ApiServiceService, private activatedRoute: ActivatedRoute, private route:Router) { }
  category = '';
  newData = [];
  newCategories = [];
  currentPage = 1;
  dataLoading = true;
  ngOnInit() {
    this.apiService.switchCategory.subscribe(res => {
      this.currentPage = 1;
      this.category = res;
      this.newData = [];
      this.getProductData(this.category);
    })
    this.category = this.activatedRoute.snapshot.params.categoryName;
    this.getProductData(this.category);
  }

  getProductData(type) {
    this.dataLoading = true;
    if (this.category !== type) {
      this.newData = [];
      this.dataLoading = false;
    }
    this.category = type;
    this.apiService.getProductList(this.category, this.currentPage).subscribe(res => {
      console.log('res', res)
      if (res.length === 0) {
        console.log('response', res);
        this.newData = [];
        this.dataLoading = false;
      }
      console.log('currentpage => ', this.currentPage);
      for (let i = 0; i < res.length; i++) {
        console.log(res)
        const defaultNew = res[i].default;
        const newObj = {
          id: res[i].id,
          title: defaultNew.name,
          categories: res[i].categories,
          description: defaultNew.description,
          price: defaultNew.price,
          variation: defaultNew.variation,
          image: defaultNew.image,
          rewardPoints: defaultNew.rewards_point,
          slug: res[i].slug
        }
        this.newData.push(newObj);
        this.newCategories.push(newObj.categories);
        if (this.newData.length) { this.dataLoading = false;}
      }
      console.log('newData', this.newData);
    })
    
  }
  onScroll() {
    this.currentPage++;
    console.log('currentpage => ', this.currentPage);
    this.getProductData(this.category);
  }

  navigateToCategories(categoryName) {
    console.log('navigate', categoryName)
    this.route.navigate([`/home/product-categories/${categoryName}`]);
    this.getProductData(categoryName);
  }
  navigateToProductDetail(data) {
    const productName = data.slug;
    console.log('productName', productName);
    this.route.navigate([`/home/product-detail/${productName}`]);
  }
}
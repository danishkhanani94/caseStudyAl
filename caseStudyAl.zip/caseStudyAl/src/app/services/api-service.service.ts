import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {
  
  constructor(private http: HttpClient) { }
  headers = new HttpHeaders()
    .set('access-key', 'f0f0682a-20db-4c63-aa12-d9214a0c5203')
  baseUrl = 'https://storeapi.airliftgrocer.com/v2/products?categorySlug=';
  productDetail = 'https://storeapi.airliftgrocer.com/v2/products?includeGroupSlugs[]='
  switchCategory: Subject<any> = new Subject<any>();


  getProductList(category, page = 1) {
    console.log('getProductList', category);
    return this.http.get<any>(`${this.baseUrl}${category}&per_page=25&page=${page}`, { 'headers': this.headers });
  }

  getProductDetail(productName) {
    // https://storeapi.airliftgrocer.com/v2/products?includeGroupSlugs[]=murree-brewerys-cindy-can-i968 
    return this.http.get<any>(`${this.productDetail}${productName}`, { 'headers': this.headers });
  }

}
